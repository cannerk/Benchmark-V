/***********DRAGGABLE PLAYER***************/
var player = document.getElementById("drag-1");

interact('#drag-1')
  .draggable({
    // enable inertial throwing
    inertia: true,
    // keep the element within the area of it's parent
    restrict: {
      restriction: "parent",
      endOnly: true,
      elementRect: { top: 0, left: 0, bottom: 1, right: 1 }
    },
    // enable autoScroll
    autoScroll: true,

    // call this function on every dragmove event
    onmove: dragMoveListener,
    // call this function on every dragend event
    onend: function (event) {
      var textEl = event.target.querySelector('p');

      textEl && (textEl.textContent =
        'moved a distance of '
        + (Math.sqrt(event.dx * event.dx +
                     event.dy * event.dy)|0) + 'px');
    }
  });

  function dragMoveListener (event) {
    var target = event.target,
        // keep the dragged position in the data-x/data-y attributes
        x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx,
        y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

    // translate the element
    target.style.webkitTransform =
    target.style.transform =
      'translate(' + x + 'px, ' + y + 'px)';

    // update the posiion attributes
    target.setAttribute('data-x', x);
    target.setAttribute('data-y', y);
  }

  // this is used later in the resizing and gesture demos
  window.dragMoveListener = dragMoveListener;




var enemyYPositions = [0, -10, -20, -30, -40, -50, -65, -75, -100, -120, -200, -250, -280, -305, -330, -340, -400, -425, -450, -500, -520, -550, -600];
var enemyXPositions = [200, 225, 250, 100, 120, 130, 300, 350, 400, 100, 50, 190, 200, 220, 60, 100, 110, 30, 300, 150, 190, 90, 255, 50, 25];
/*var player = 0;
var player = 0;
var avatarImage;*/
var enemyImage;



var gameCanvas = document.getElementById("gameCanvas");
 
 
function setUpGame() {
 /*   avatarImage = new Image();*/
    enemyImage = new Image();
    enemyImage.src = "img/defender.png";
  /*  avatarImage.src = "img/player.gif";*/
    /*gameCanvas.getContext("2d").drawImage(avatarImage, Math.random() * 300, Math.random() * 300);*/
     
    gameCanvas.addEventListener("mousemove", handleMouseMovement);
    setInterval(handleTick, 25);
}
 
function handleMouseMovement(mouseEvent) {
    /*player = mouseEvent.offsetX;
    player = mouseEvent.offsetY;
	console.log(mouseEvent.offsetY);*/
     if (player < 65) {
		 location.replace("touchdown.html")
		document.getElementById("confetti").style.display="block";	
		document.getElementById("gameCanvas").style.display="none";
		
	 }
	 
    if (mouseEvent.offsetX > 22 && mouseEvent.offsetX < 28 && mouseEvent.offsetY > 11 && mouseEvent.offsetY < 18) {
     
	  location.replace("hit_blocker.html");
	  
    }
}
 
function handleTick() {
    var gameCanvas = document.getElementById("gameCanvas");
    var currentEnemyNumber = 0;
    var numberOfEnemies = enemyXPositions.length;
 
    while (currentEnemyNumber < numberOfEnemies) {
        enemyYPositions[currentEnemyNumber] = enemyYPositions[currentEnemyNumber] + 1;
        currentEnemyNumber = currentEnemyNumber + 1;
    }
     
    gameCanvas.width = 400;     //this erases the contents of the canvas
/*    gameCanvas.getContext("2d").drawImage(avatarImage, player, player);
*/     
    currentEnemyNumber = 0;
    while (currentEnemyNumber < numberOfEnemies) {
        gameCanvas.getContext("2d").drawImage(enemyImage, enemyXPositions[currentEnemyNumber], enemyYPositions[currentEnemyNumber]);
        currentEnemyNumber = currentEnemyNumber + 1;
    }
	
	if ( ( (player < enemyXPositions[0] && enemyXPositions[0] < player + 30) || (enemyXPositions[0] < player && player < enemyXPositions[0] + 30) ) && ( (player < enemyYPositions[0] && enemyYPositions[0] < player + 33) || (enemyYPositions[0] < player && player < enemyYPositions[0] + 30) ) ) {
      location.replace("hit_blocker.html");;
    }
	currentEnemyNumber = 0;
while (currentEnemyNumber < numberOfEnemies) {
    if ( ( (player < enemyXPositions[currentEnemyNumber] && enemyXPositions[currentEnemyNumber] < player + 30) || (enemyXPositions[currentEnemyNumber] < player && player < enemyXPositions[currentEnemyNumber] + 30) ) && ( (player < enemyYPositions[currentEnemyNumber] && enemyYPositions[currentEnemyNumber] < player + 33) || (enemyYPositions[currentEnemyNumber] < player && player < enemyYPositions[currentEnemyNumber] + 30) ) ) {
       location.replace("hit_blocker.html");
    }
    currentEnemyNumber = currentEnemyNumber + 1;
}
}


document.getElementById("go_back").onclick = function(){
	location.replace("index.html");
}
